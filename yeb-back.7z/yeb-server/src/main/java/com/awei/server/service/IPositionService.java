package com.awei.server.service;

import com.awei.server.pojo.Position;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author shizuwei
 * @since 2021-03-09
 */
public interface IPositionService extends IService<Position> {

}
