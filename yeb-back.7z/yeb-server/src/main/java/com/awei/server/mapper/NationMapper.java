package com.awei.server.mapper;

import com.awei.server.pojo.Nation;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author shizuwei
 * @since 2021-03-09
 */
public interface NationMapper extends BaseMapper<Nation> {

}
