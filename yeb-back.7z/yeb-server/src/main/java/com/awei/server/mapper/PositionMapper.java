package com.awei.server.mapper;

import com.awei.server.pojo.Position;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author shizuwei
 * @since 2021-03-09
 */
public interface PositionMapper extends BaseMapper<Position> {

}
