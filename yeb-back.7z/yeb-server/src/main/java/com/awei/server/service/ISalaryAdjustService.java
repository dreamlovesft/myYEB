package com.awei.server.service;

import com.awei.server.pojo.SalaryAdjust;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author shizuwei
 * @since 2021-03-09
 */
public interface ISalaryAdjustService extends IService<SalaryAdjust> {

}
